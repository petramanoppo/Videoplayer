package id.ac.umn.uts_00000048162_arnoldusyitzhakpetramanoppo;

public interface RecyclerInterface {
    void onItemClick(int position);

    void onDelete(int position);
}
